#ifndef HW2_TEXEL_H
#define HW2_TEXEL_H

#include "global.h"

struct Texel {
    GLubyte red;
    GLubyte green;
    GLubyte blue;
};

#endif //HW2_TEXEL_H
